<!DOCTYPE HTML>
<html>
<head>
    <title></title>
</head>
<body>
<p>Bonjour</p>
<?php require('vue.php')?>
</body>
</html>